/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
 
/**
 *
 * @ MAKHENSE MALVIN
 */
   import java.io.FileWriter;
   import java.io.IOException;
   import java.util.ArrayList;
   import java.util.Random;
   import java.util.Scanner;
   
public class Message {
  
    //============================
    
    private String messageID;
    private int messageNumber;
    private String recipient;
    private String message;
    private String messageHash;
    private String messageStatus;
    
    //Stores message sent during the program
    private static ArrayList<Message> sentMessages = new ArrayList<>();
    
    //Stores messages that were disregarded
    private static ArrayList<Message> disregardedMessages = new ArrayList<>();
    
    //Stores messages saved for later
    private static ArrayList<Message> storedMessages = new ArrayList<>();
    
    //Total number of messages sent
    private static int totalMessages = 0;
    
    //===================================
    //CONSTRUCTOR
    //===================================
    
    public Message(
            String messageID,
            int messageNumber,
            String recipient,
            String message){
        
        this.messageID = messageID;
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.message = message;
        this.messageHash = createMessageHash();
    }
    
    //=====================================================
    //Start QUICKCHAT
    //=====================================================
    
    public static void startQuickChat(Scanner input) {
        
        //Ask how many messages they want to enter
        System.out.print("How many messages would you like to enter?");
    
    
    int numberOfMessages = input.nextInt();
    input.nextLine();
    
    //Application menu loop
    boolean running = true;
    
    while (running) {  
        System.out.println("\n====================");
        System.out.println("     QUICKCHAT      ");
        System.out.println("\n====================");
        System.out.println("1. Send Messages");
        System.out.println("2. Show recently sent messages");
        System.out.println("3. Quit");
        System.out.print("Choose an option:");
    
        String option = input.nextLine();
    
        switch (option) {
          
            case "1":
              
                Message(input, numberOfMessages);
    
                break;
    
            case "2":
    
              System.out.println("\nComing Soon");
    
                 break;
    
            case "3":
                 
                 running = false;
                 
                 System.out.println("\nThank you for using QuickChat.");
                 
                 break;
                 
            default:
    
                System.out.println("Invalid option. Please select 1, 2 or 3.");
            }
       }
    }
    
    //=============================================
    //Send Messages
    //=============================================
    
    public static void Message (
        Scanner input,
        int numberOfMessages) {

    for (int i = 1; i <= numberOfMessages; i++) {

        System.out.println("\n=========================");
        System.out.println("Message" + i);
        System.out.println("\n=========================");

        String messageID = generateMessageID();

        System.out.println("Message ID generated:" + messageID);

        String recipient;

        while (true) {

            System.out.print("Enter recipient cellphone number");
            recipient = input.nextLine();

            Message temporaryMessage = new Message(
                    messageID,
                    i,
                    recipient,
                    "");

            if (temporaryMessage.checkRecipientCell()) {
                System.out.println("Cellphone number succesfully captured");
                break;

            } else {
                System.out.println("Cellphone number is incorrectly formated"
                        + "or does not contain an international code");
            }
        }   // closes recipient while

        String messageText;

        while (true) {

            System.out.print("Enter your message.");
            messageText = input.nextLine();

            if (messageText.length() <= 250) {
                System.out.println("Message ready to send.");
                break;

            } else {
                System.out.println("Please enter a message of less than 250 "
                        + "characters.");
            }
        }   // closes message while

        Message newMessage = new Message(
                messageID,
                i,
                recipient,
                messageText);

        System.out.println("Message Hash:" + newMessage.createMessageHash());

        String result = newMessage.SentMessage(input);

        System.out.println("\n" + result);

        if (newMessage.messageStatus.equals("Sent")) {

            System.out.println("\n=========================");
            System.out.println("Message ID:" + newMessage.messageID);
            System.out.println("Message Hash:" + newMessage.messageHash);
            System.out.println("Recipient:" + newMessage.recipient);
            System.out.println("Message:" + newMessage.message);
            System.out.println("=========================");
        }

    }   // closes for loop

    System.out.println("\nTotal messages sent:" + returnTotalMessages());
}   // closes sendMessage

    
    public boolean checkRecipientCell() {
        
        return recipient != null && recipient.matches("^\\+[0-9]{1,3}[0-9]{1,10}");
    }
    
    // CREATE MESSAGE HASH
    
    public String createMessageHash(){
        
        String firstTwoNumbers;
        
        if (messageID.length() >=2){
             
            firstTwoNumbers =
                 messageID.substring(0, 2);
                
        } else {
    
            firstTwoNumbers = messageID;
        }
        
        String firstWord = "";
        String lastWord = "";
        
        if (message != null && !message.trim().isEmpty()) {
            
            String cleanMessage = message.trim();
            
            String[] words = cleanMessage.split("\\s+");
            
            firstWord = words[0];
            
            lastWord = words[words.length - 1];
            
            //Remove punctuation
            firstWord = firstWord.replaceAll("[^a-zA-Z0-9]", "");
            lastWord = lastWord.replaceAll("[^a-zA-Z0-9]", "");
        }

        //ADDED: build the hash, e.g. 00:0:HITONIGHT
        String hash = firstTwoNumbers + ":" + messageNumber + ":"
                + firstWord + lastWord;

        return hash.toUpperCase();
    }

    //====================================================
    //Generate Message ID (random ten-digit number)
    //====================================================

    public static String generateMessageID() {

        Random random = new Random();

        String id = "";

        for (int i = 0; i < 10; i++) {

            id = id + random.nextInt(10);
        }

        return id;
    }

    //====================================================
    //Check Message ID (not more than ten characters)
    //====================================================

    public boolean checkMessageID() {

        return messageID != null && messageID.length() <= 10;
    }

    //====================================================
    //Check Message Length (used for the unit tests)
    //====================================================

    public String checkMessageLength() {

        if (message.length() <= 250) {

            return "Message ready to send.";

        } else {

            int extra = message.length() - 250;

            return "Message exceeds 250 characters by " + extra
                    + ", please reduce the size.";
        }
    }

    //====================================================
    //Sent Message (send, disregard or store)
    //====================================================

    public String SentMessage(Scanner input) {

        String choice;

        while (true) {

            System.out.println("\n1. Send Message");
            System.out.println("2. Disregard Message");
            System.out.println("3. Store Message to send later");
            System.out.print("Choose an option:");

            choice = input.nextLine();

            if (choice.equals("1") || choice.equals("2") || choice.equals("3")) {

                break;

            } else {

                System.out.println("Invalid option. Please select 1, 2 or 3.");
            }
        }

        return SentMessage(choice);
    }

    //Same method with the choice passed in (so it can be unit tested)
    public String SentMessage(String choice) {

        switch (choice) {

            case "1":

                messageStatus = "Sent";

                sentMessages.add(this);

                totalMessages++;

                return "Message successfully sent.";

            case "2":

                messageStatus = "Disregarded";

                disregardedMessages.add(this);

                return "Press 0 to delete the message.";

            case "3":

                messageStatus = "Stored";

                storeMessage();

                return "Message successfully stored.";

            default:

                return "Invalid option.";
        }
    }

    //====================================================
    //Print Messages (all messages sent while program runs)
    //====================================================

    public static String printMessages() {

        String allMessages = "";

        for (Message sent : sentMessages) {

            allMessages = allMessages
                    + "Message ID: " + sent.messageID + "\n"
                    + "Message Hash: " + sent.messageHash + "\n"
                    + "Recipient: " + sent.recipient + "\n"
                    + "Message: " + sent.message + "\n\n";
        }

        return allMessages;
    }

    //====================================================
    //Return Total Messages
    //====================================================

    public static int returnTotalMessages() {

        return totalMessages;
    }

    //====================================================
    //Store Message in a JSON file
    //====================================================

    public void storeMessage() {

        storedMessages.add(this);

        try {

            FileWriter writer = new FileWriter("storedMessages.json");

            writer.write("[\n");

            for (int i = 0; i < storedMessages.size(); i++) {

                Message stored = storedMessages.get(i);

                writer.write("  {\n");
                writer.write("    \"messageID\": \"" + stored.messageID + "\",\n");
                writer.write("    \"messageHash\": \"" + stored.messageHash + "\",\n");
                writer.write("    \"recipient\": \"" + stored.recipient + "\",\n");
                writer.write("    \"message\": \""
                        + stored.message.replace("\"", "\\\"") + "\"\n");

                if (i < storedMessages.size() - 1) {

                    writer.write("  },\n");

                } else {

                    writer.write("  }\n");
                }
            }

            writer.write("]");

            writer.close();

        } catch (IOException e) {

            System.out.println("Error storing message: " + e.getMessage());
        }
    }
}
       
