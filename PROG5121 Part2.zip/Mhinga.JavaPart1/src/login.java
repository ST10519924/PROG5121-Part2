/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Student
 */
import java.util.Scanner;

public class login {

    // Pure check, no console input - this is what the unit tests call
    public static boolean loginUser(
            String storedUsername,
            String storedPassword,
            String enteredUsername,
            String enteredPassword) {

        return storedUsername != null
                && storedPassword != null
                && storedUsername.equals(enteredUsername)
                && storedPassword.equals(enteredPassword);
    }

    // Interactive login: keeps asking until the details match
    public static boolean loginUser(
            Scanner input,
            String storedUsername,
            String storedPassword,
            String name,
            String surname) {

        System.out.println();
        System.out.println("====== LOGIN PAGE ======");

        while (true) {

            System.out.println("Enter your username:");
            String enteredUsername = input.nextLine();

            System.out.println("Enter your password:");
            String enteredPassword = input.nextLine();

            if (loginUser(storedUsername, storedPassword, enteredUsername, enteredPassword)) {
                return true;
            }

            System.out.println();
            System.out.println("Username or password incorrect.");
            System.out.println("Please try again.");
            System.out.println();
        }
    }

    public static String returnLoginStatus(
            boolean loginSuccessful,
            String name,
            String surname) {

        if (loginSuccessful) {
            return "Welcome " + name + " " + surname + " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}