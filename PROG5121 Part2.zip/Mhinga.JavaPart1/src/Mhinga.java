
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */


/**
 *
 * @author Student
 */

import java.util.Scanner;

public class Mhinga {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        String name;
        String surname;
        String username;
        String password;
        String phoneNum;

        // Name
        System.out.println("Please enter your name:");
        name = input.nextLine();

        // Surname
        System.out.println("Please enter your surname:");
        surname = input.nextLine();

        // Username
        while (true) {
            System.out.println("Please enter your username:");
            username = input.nextLine();

            if (checkUserName(username)) {
                System.out.println("Username successfully captured.");
                break;
            } else {
                System.out.println("Username is not correctly formatted.");
                System.out.println("Username must contain an underscore.");
                System.out.println("Username must be no more than 5 characters long.");
            }
        }

        // Password
        while (true) {
            System.out.println("Please enter your password:");
            password = input.nextLine();

            if (checkPassword(password)) {
                System.out.println("Password successfully captured.");
                break;
            } else {
                System.out.println("Password is not correctly formatted.");
                System.out.println("Password must be at least 8 characters long.");
                System.out.println("Password must contain a capital letter.");
                System.out.println("Password must contain a number.");
                System.out.println("Password must contain a special character.");
            }
        }

        // Phone number
        while (true) {
            System.out.println("Please enter your cellphone number:");
            phoneNum = input.nextLine();

            if (checkPhoneNum(phoneNum)) {
                System.out.println("Phone number successfully added.");
                break;
            } else {
                System.out.println("Cellphone number incorrectly formatted.");
                System.out.println("Cellphone number must start with +27.");
                System.out.println("Cellphone number must be no more than 10 characters.");
            }
        }

        // Register user
        String registrationMessage = registerUser(
                username,
                password,
                phoneNum,
                name,
                surname
        );

        System.out.println(registrationMessage);

        // Login
        boolean loginSuccessful = login.loginUser(
                input,
                username,
                password,
                name,
                surname
        );

        // Display login status
        String loginMessage = login.returnLoginStatus(
                loginSuccessful,
                name,
                surname
        );

        System.out.println(loginMessage);
        
        System.out.println("Login result: " + loginSuccessful);   // temporary test line

        if (loginSuccessful) {
            System.out.println("Welcome to QuickChat.");
            Message.startQuickChat(input);

        input.close();
    }}

    // Check username
    public static boolean checkUserName(String username) {

        // Username must be at least 5 characters
        if (username.length() > 5) {
            return false;
        }

        // Username must contain an underscore
        if (!username.contains("_")) {
            return false;
        }

        return true;
    }

    // Check password
    public static boolean checkPassword(String password) {

        if (password.length() < 8) {
            return false;
        }

        boolean hasCapitalLetter = false;
        boolean hasNumber = false;
        boolean hasSpecialCharacter = false;

        for (int i = 0; i < password.length(); i++) {

            char ch = password.charAt(i);

            if (Character.isUpperCase(ch)) {
                hasCapitalLetter = true;
            }

            
            if (Character.isDigit(ch)) {
                hasNumber = true;
            }

            // Special character means it is not a letter, number or underscore
            if (!Character.isLetterOrDigit(ch)) {
                hasSpecialCharacter = true;
            }
        }

        return hasCapitalLetter
                && hasNumber
                && hasSpecialCharacter;
    }

    // Check phone number
    public static boolean checkPhoneNum(String phoneNum) {
     
        if (phoneNum.length() < 10) {
        
            return false;
        }
     
        return phoneNum.startsWith("+27");
    }
    
     

    // Register user
    public static String registerUser(
            String username,
            String password,
            String phoneNum,
            String name,
            String surname) {

        if (!checkUserName(username)) {
            return "Username is not correctly formatted.";
        }

        if (!checkPassword(password)) {
            return "Password is not correctly formatted.";
        }

        if (!checkPhoneNum(phoneNum)) {
            return "Phone number incorrectly formatted.";
        }

        return "Registration successfully completed.";
    }

}

 





       



    
   