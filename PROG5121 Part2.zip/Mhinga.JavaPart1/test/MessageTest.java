/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author MAKHENSE MALVIN
 */
import static org.junit.Assert.*;
import org.junit.Test;

public class MessageTest {

    @Test
    public void testCheckMessageIDSuccess() {
        Message msg = new Message();
        // Assuming checkMessageID checks if length <= 10
        assertTrue(msg.checkMessageID("1234567890"));
    }

    @Test
    public void testCheckMessageIDFailure() {
        Message msg = new Message();
        assertFalse(msg.checkMessageID("12345678901"));
    }

    @Test
    public void testCheckRecipientCellSuccess() {
        Message msg = new Message();
        // Assuming valid format contains international code and valid length
        assertTrue(msg.checkRecipientCell("+27718659302"));
    }

    @Test
    public void testCheckRecipientCellFailure() {
        Message msg = new Message();
        assertFalse(msg.checkRecipientCell("0837097988"));
    }

    @Test
    public void testCheckMessageLengthSuccess() {
        Message msg = new Message();
        String result = msg.checkMessageLength("Hi Mike, can you join us for dinner tonight?");
        assertEquals("Message ready to send.", result);
    }

    @Test
    public void testCheckMessageLengthFailure() {
        Message msg = new Message();
        // Creating a string longer than 250 characters
        String longMessage = new String(new char[251]).replace("\0", "a");
        String result = msg.checkMessageLength(longMessage);
        assertTrue(result.contains("Message exceeds 250 characters"));
    }

    @Test
    public void testCreateMessageHash() {
        Message msg = new Message();
        // Set up dummy values if needed or test the format generation
        // Format based on spec: first two numbers of ID, colon, number of words, first and last words in caps
        String hash = msg.createMessageHash();
        assertNotNull(hash);
    }

    @Test
    public void testSentMessageOption1() {
        Message msg = new Message();
        String result = msg.sentMessage("1");
        assertEquals("Message successfully sent.", result);
    }

    @Test
    public void testSentMessageOption2() {
        Message msg = new Message();
        String result = msg.sentMessage("2");
        assertEquals("Press 0 to delete the message.", result);
    }

    @Test
    public void testSentMessageOption3() {
        Message msg = new Message();
        String result = msg.sentMessage("3");
        assertEquals("Message successfully stored.", result);
    }
}
