/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */


import org.junit.Test;
import static org.junit.Assert.*;
 
public class LoginTest {
 
    @Test
    public void testCheckUserName() {
        assertTrue("Valid username should return true", Mhinga.checkUserName("kyl_1"));
        assertFalse("Too long / no underscore should return false", Mhinga.checkUserName("kyle!!!!!!!"));
    }
 
    @Test
    public void testCheckPasswordComplexity() {
        assertTrue("Valid password should return true", Mhinga.checkPassword("Ch&&sec@ke99!"));
        assertFalse("Invalid password should return false", Mhinga.checkPassword("password"));
    }
 
    @Test
    public void testCheckCellPhoneNumber() {
        assertTrue("Valid phone should return true", Mhinga.checkPhoneNum("+27838968976"));
        assertFalse("Invalid phone should return false", Mhinga.checkPhoneNum("08966553"));
    }
 
    @Test
    public void testRegisterUser() {
        assertEquals("Registration successful.",
                Mhinga.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith"));
 
        assertEquals("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.",
                Mhinga.registerUser("kyle!!!!!!!", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Smith"));
 
        assertEquals("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.",
                Mhinga.registerUser("kyl_1", "password", "+27838968976", "Kyle", "Smith"));
 
        assertEquals("Cell phone number incorrectly formatted or does not contain international code.",
                Mhinga.registerUser("kyl_1", "Ch&&sec@ke99!", "08966553", "Kyle", "Smith"));
    }
 
    @Test
    public void testLoginUser() {
        assertTrue("Correct credentials should return true",
                login.loginUser("kyl_1", "Ch&&sec@ke99!", "kyl_1", "Ch&&sec@ke99!"));
        assertFalse("Incorrect credentials should return false",
                login.loginUser("kyl_1", "Ch&&sec@ke99!", "wrong", "wrongpass"));
    }
 
    @Test
    public void testReturnLoginStatus() {
        assertEquals("Welcome Kyle Smith it is great to see you again.",
                login.returnLoginStatus(true, "Kyle", "Smith"));
        assertEquals("Username or password incorrect, please try again.",
                login.returnLoginStatus(false, "Kyle", "Smith"));
    }
}
 